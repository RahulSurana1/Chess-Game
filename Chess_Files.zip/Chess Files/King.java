
public class King extends ChessPiece
{
    public King(int nRow, int nCol, boolean black)
    {
        super(nRow, nCol, black, 5);
    }

    public static boolean kingValidMove(int fromRow, int fromCol, int toRow, int toCol, ChessPiece[][] Board, boolean turn)
    {
        if(Board[fromRow][fromCol]==null)
        {
            return false;
        }
        else
        {
            if(Math.abs(toRow-fromRow)<2 && Math.abs(toCol-fromCol)<2)
            {
                if(Board[toRow][toCol]==null)
                {
                    return true;
                }
                else
                {
                    if(Board[fromRow][fromCol].isBlack()!=Board[toRow][toCol].isBlack())
                    {
                        Board[toRow][toCol]=null;
                        return true;
                    }
                    else
                        return false;
                }
            }
            else
                return false;
        }
    }

    public static boolean kingMove (int fromRow, char fromCol, int toRow, char toCol, ChessPiece[][] Board, boolean turn)
    {
        int iFromCol= fromCol-97;
        int iToCol= toCol-96;
        toRow=7-toRow;
        fromRow=7-fromRow;

        if (turn==true && Board[fromRow][iFromCol].isBlack()==true)
        {
            if(kingValidMove(fromRow, iFromCol, toRow, iToCol, Board, turn)==true)
            {
                System.out.println(toRow);
                System.out.println(iToCol);
                if(Board[toRow][iToCol].getType()==0)
                {

                    Pawn temp2 = new Pawn (toRow, iToCol, false);
                    King temp = new King(toRow, iToCol, true);
                    Board[fromRow][iFromCol]= null;
                    Board[toRow][iToCol]=temp;
                    ChessBoard.blackKingSet(toRow, iToCol);
                    if(checkKingMove(Board,turn)==false)
                    {
                        Board[toRow][iToCol]=temp2;
                        Board[fromRow][iFromCol]=temp;
                    }
                    else
                    {
                        ChessBoard.blackKingSet(toRow, iToCol);
                    }
                }
                else
                {
                    if(Board[toRow][iToCol].getType()==1)
                    {
                        Rook temp2 = new Rook (toRow, iToCol, false);
                        King temp = new King(toRow, iToCol, true);
                        Board[fromRow][iFromCol]= null;
                        Board[toRow][iToCol]=temp;
                        ChessBoard.blackKingSet(toRow, iToCol);
                        if(checkKingMove(Board,turn)==false)
                        {
                            Board[toRow][iToCol]=temp2;
                            Board[fromRow][iFromCol]=temp;
                        }
                        else
                        {
                            ChessBoard.blackKingSet(toRow, iToCol);
                        }
                    }
                    else
                    {
                        if(Board[toRow][iToCol].getType()==2)
                        {
                            Knight temp2 = new Knight (toRow, iToCol, false);
                            King temp = new King(toRow, iToCol, true);
                            Board[fromRow][iFromCol]= null;
                            Board[toRow][iToCol]=temp;
                            ChessBoard.blackKingSet(toRow, iToCol);
                            if(checkKingMove(Board,turn)==false)
                            {
                                Board[toRow][iToCol]=temp2;
                                Board[fromRow][iFromCol]=temp;
                            }
                            else
                            {
                                ChessBoard.blackKingSet(toRow, iToCol);
                            }
                        }
                        else
                        {
                            if(Board[toRow][iToCol].getType()==3)
                            {
                                Bishop temp2 = new Bishop (toRow, iToCol, false);
                                King temp = new King(toRow, iToCol, true);
                                Board[fromRow][iFromCol]= null;
                                Board[toRow][iToCol]=temp;
                                ChessBoard.blackKingSet(toRow, iToCol);
                                if(checkKingMove(Board,turn)==false)
                                {
                                    Board[toRow][iToCol]=temp2;
                                    Board[fromRow][iFromCol]=temp;
                                }
                                else
                                {
                                    ChessBoard.blackKingSet(toRow, iToCol);
                                }
                            }
                            else
                            {
                                if(Board[toRow][iToCol].getType()==4)
                                {
                                    Queen temp2 = new Queen (toRow, iToCol, false);
                                    King temp = new King(toRow, iToCol, true);
                                    Board[fromRow][iFromCol]= null;
                                    Board[toRow][iToCol]=temp;
                                    ChessBoard.blackKingSet(toRow, iToCol);
                                    if(checkKingMove(Board,turn)==false)
                                    {
                                        Board[toRow][iToCol]=temp2;
                                        Board[fromRow][iFromCol]=temp;
                                    }
                                    else
                                    {
                                        ChessBoard.blackKingSet(toRow, iToCol);
                                    }
                                }
                                else
                                {
                                    if(Board[toRow][iToCol]==null)
                                    {
                                        King temp = new King(toRow, iToCol, true);
                                        Board[fromRow][iFromCol]= null;
                                        Board[toRow][iToCol]=temp;
                                        ChessBoard.blackKingSet(toRow, iToCol);
                                        if(checkKingMove(Board,turn)==false)
                                        {
                                            Board[fromRow][iFromCol]=temp;
                                        }
                                        else
                                        {
                                            ChessBoard.blackKingSet(toRow, iToCol);
                                        }
                                    }
                                }

                            }
                        }
                    }
                }

                turn=false;
                return true;
            }
        }
        else
        {
            if(turn==false && Board[fromRow][iFromCol].isBlack()==false)
            {
                if(kingValidMove(fromRow, iFromCol, toRow, iToCol, Board, turn)==true)
                {
                    if(Board[toRow][iToCol]==null)
                    {
                        King temp = new King(toRow, iToCol, false);
                        Board[fromRow][iFromCol]= null;
                        Board[toRow][iToCol]=temp;
                        ChessBoard.whiteKingSet(toRow, iToCol);
                        if(checkKingMove(Board,turn)==false)
                        {
                            Board[fromRow][iFromCol]=temp;
                            Board[toRow][iToCol]=null;
                        }
                        else
                        {
                            ChessBoard.whiteKingSet(toRow, iToCol);
                        }
                    }
                    else
                    {
                        if(Board[toRow][iToCol].getType()==0)
                        {
                            Pawn temp2 = new Pawn (toRow, iToCol, true);
                            King temp = new King(toRow, iToCol, false);
                            Board[fromRow][iFromCol]= null;
                            Board[toRow][iToCol]=temp;
                            ChessBoard.whiteKingSet(toRow, iToCol);
                            if(checkKingMove(Board,turn)==false)
                            {
                                Board[toRow][iToCol]=temp2;
                                Board[fromRow][iFromCol]=temp;
                            }
                            else
                            {
                                ChessBoard.whiteKingSet(toRow, iToCol);
                            }
                        }
                        else
                        {
                            if(Board[toRow][iToCol].getType()==1)
                            {
                                Rook temp2 = new Rook (toRow, iToCol, true);
                                King temp = new King(toRow, iToCol, false);
                                Board[fromRow][iFromCol]= null;
                                Board[toRow][iToCol]=temp;
                                ChessBoard.whiteKingSet(toRow, iToCol);
                                if(checkKingMove(Board,turn)==false)
                                {
                                    Board[toRow][iToCol]=temp2;
                                    Board[fromRow][iFromCol]=temp;
                                }
                                else
                                {
                                    ChessBoard.whiteKingSet(toRow, iToCol);
                                }
                            }
                            else
                            {
                                if(Board[toRow][iToCol].getType()==2)
                                {
                                    Knight temp2 = new Knight (toRow, iToCol, true);
                                    King temp = new King(toRow, iToCol, false);
                                    Board[fromRow][iFromCol]= null;
                                    Board[toRow][iToCol]=temp;
                                    ChessBoard.whiteKingSet(toRow, iToCol);
                                    if(checkKingMove(Board,turn)==false)
                                    {
                                        Board[toRow][iToCol]=temp2;
                                        Board[fromRow][iFromCol]=temp;
                                    }
                                    else
                                    {
                                        ChessBoard.whiteKingSet(toRow, iToCol);
                                    }
                                }
                                else
                                {
                                    if(Board[toRow][iToCol].getType()==3)
                                    {
                                        Bishop temp2 = new Bishop (toRow, iToCol, true);
                                        King temp = new King(toRow, iToCol, false);
                                        Board[fromRow][iFromCol]= null;
                                        Board[toRow][iToCol]=temp;
                                        ChessBoard.whiteKingSet(toRow, iToCol);
                                        if(checkKingMove(Board,turn)==false)
                                        {
                                            Board[toRow][iToCol]=temp2;
                                            Board[fromRow][iFromCol]=temp;
                                        }
                                        else
                                        {
                                            ChessBoard.whiteKingSet(toRow, iToCol);
                                        }
                                    }
                                    else
                                    {
                                        if(Board[toRow][iToCol].getType()==4)
                                        {
                                            Queen temp2 = new Queen (toRow, iToCol, true);
                                            King temp = new King(toRow, iToCol, false);
                                            Board[fromRow][iFromCol]= null;
                                            Board[toRow][iToCol]=temp;
                                            ChessBoard.whiteKingSet(toRow, iToCol);
                                            if(checkKingMove(Board,turn)==false)
                                            {
                                                Board[toRow][iToCol]=temp2;
                                                Board[fromRow][iFromCol]=temp;
                                            }
                                            else
                                            {
                                                ChessBoard.whiteKingSet(toRow, iToCol);
                                            }
                                        }
                                        else
                                        {
                                            if(Board[toRow][iToCol]==null)
                                            {
                                                King temp = new King(toRow, iToCol, false);
                                                Board[fromRow][iFromCol]= null;
                                                Board[toRow][iToCol]=temp;
                                                ChessBoard.whiteKingSet(toRow, iToCol);
                                                if(checkKingMove(Board,turn)==false)
                                                {
                                                    Board[fromRow][iFromCol]=temp;
                                                }
                                                else
                                                {
                                                    ChessBoard.whiteKingSet(toRow, iToCol);
                                                }
                                            }
                                        }

                                    }
                                }
                            }
                        }
                    }
                    turn=true;
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean checkKingMove (ChessPiece[][] Board, boolean turn)
    {
        if(kingCheck.checkMove(Board, turn)==false)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

}



