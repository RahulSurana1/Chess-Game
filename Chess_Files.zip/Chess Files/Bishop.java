public class Bishop extends ChessPiece
{
    public Bishop(int nRow, int nCol, boolean black)
    {
        super(nRow, nCol, black, 3);
    }

    public static boolean bishopValidMove(int fromRow, int fromCol, int toRow, int toCol, ChessPiece[][] Board, boolean turn)
    {
        boolean valid = true;
        int col=toCol;
        if(Board[fromRow][fromCol]==null)
        {
            return false;
        }
        else
        {
            if(Math.abs(fromRow-toRow) == Math.abs(fromCol-toCol))
            {
                if(fromRow>toRow)
                {
                    if(fromCol>toCol)
                    {
                        for(int row=toRow; row<fromRow; row++)
                        {
                            if (Board[row][col] == null)
                            {
                                valid = true;
                                col++;
                            }
                            else
                            {
                                if(row==toRow && col==toCol)
                                {
                                    if(Board[fromRow][fromCol].isBlack() != Board[toRow][toCol].isBlack())
                                    {
                                        valid = true;
                                        col++;
                                    }
                                }
                                else
                                {
                                    return false;
                                }
                            }

                        }
                        return valid;
                    }
                    else
                    {
                        if(fromCol<toCol)
                        {
                            for(int row=toRow; row<fromRow; row++)
                            {
                                System.out.println(row);
                                System.out.println(col);
                                if (Board[row][col] == null)
                                {
                                    valid = true;
                                    col--;
                                }
                                else
                                {
                                    if(row==toRow && col==toCol)
                                    {
                                        if(Board[fromRow][fromCol].isBlack() != Board[toRow][toCol].isBlack())
                                        {
                                            valid = true;
                                            col--;
                                        }
                                    }
                                    else
                                    {
                                        return false;
                                    }
                                }
                            }
                            return valid;
                        }
                    }
                }
                else
                {
                    if(fromRow<toRow)
                    {
                        if(fromCol>toCol)
                        {
                            for(int row=toRow; row>fromRow; row--)
                            {
                                if (Board[row][col] == null)
                                {
                                    valid = true;
                                    col++;
                                }
                                else
                                {
                                    if(row==toRow && col==toCol)
                                    {
                                        if(Board[fromRow][fromCol].isBlack() != Board[toRow][toCol].isBlack())
                                        {
                                            valid = true;
                                            col++;
                                        }
                                    }
                                    else
                                    {
                                        return false;
                                    }
                                }
                            }
                            return valid;
                        }
                        if(fromCol<toCol)
                        {
                            System.out.println("Error: 1");
                            for(int row=toRow; row>fromRow; row--)
                            {
                                if (Board[row][col] == null)
                                {
                                    System.out.println("Error: 2");
                                    valid = true;
                                    col--;
                                }
                                else
                                {
                                    if(row==toRow && col==toCol)
                                    {
                                        if(Board[toRow][toCol].isBlack() != Board[fromRow][toCol].isBlack())
                                        {
                                            System.out.println("Error: 3");
                                            valid = true;
                                            col--;
                                        }
                                    }
                                    else
                                    {
                                        System.out.println("Error: 4");
                                        System.out.println(Board[row][col]);
                                        System.out.println(row);
                                        System.out.println(col);
                                        return false;
                                    }
                                }
                            }
                            return valid;
                        }
                    }
                }
            }
        }
        return false;
    }
    public static boolean bishopMove(int fromRow, char fromCol, int toRow, char toCol, ChessPiece[][] Board, boolean turn)
    {
        int iFromCol= fromCol-97;
        int iToCol= toCol-97;
        toRow=7-toRow;
        fromRow=7-fromRow;

        if (turn==true && Board[fromRow][iFromCol].isBlack()==true)
        {
            if(bishopValidMove(fromRow, iFromCol, toRow, iToCol, Board, turn)==true)
            {
                Bishop temp = new Bishop(toRow, iToCol, true);
                Board[fromRow][iFromCol]= null;
                Board[toRow][iToCol]=temp;
                turn=false;
                return true;
            }
        }
        else
        {
            if(turn==false && Board[fromRow][iFromCol].isBlack()==false)
            {
                if(bishopValidMove(fromRow, iFromCol, toRow, iToCol, Board, turn)==true)
                {
                    Bishop temp = new Bishop(toRow, iToCol, false);
                    Board[fromRow][iFromCol]= null;
                    Board[toRow][iToCol]=temp;
                    turn=true;
                    return true;
                }
            }
        }
        return false;
    }
}












