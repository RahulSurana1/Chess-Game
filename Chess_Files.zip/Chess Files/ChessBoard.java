
public class ChessBoard
{
    private int boardLength;
    private static ChessPiece[][] Board = new ChessPiece[8][8];
    static boolean blackTurn=false;
    boolean isCastle=false;
    private int blackCount=16;
    private int whiteCount=16;
    private int whiteCounter=0;
    private int blackCounter=0;
    private static int blackKingRow=1;
    private static int blackKingCol=5;
    private static int whiteKingRow=8;
    private static int whiteKingCol=5;
    static boolean isWhiteCheck=false;
    static boolean isBlackCheck=false;

    public ChessBoard (int length)
    {
        ChessPiece cboard[][]= new ChessPiece[length][length];
        boardLength=length;
        Board=cboard;
    }

    public void printBoard()
    {
        System.out.println("  a b c d e f g h");
        for (int r=0; r<boardLength; r++)
        {

            for (int c=0; c<boardLength; c++)
            {
                if (c==0)
                {
                    System.out.print(8-r + " "); //Prints out the verical index.
                }
                if (Board[r][c]==null)
                {
                    System.out.print("-" + " "); //Prints out a dash if no piece is there.
                }
                else if (Board[r][c].isBlack()==true && Board[r][c].getType()==0)
                {
                    System.out.print("p" + " "); //Prints out a black king piece.
                }
                else if (Board[r][c].isBlack()==true && Board[r][c].getType()==1)
                {
                    System.out.print("r" + " "); //Prints out a black king piece.
                }
                else if (Board[r][c].isBlack()==true && Board[r][c].getType()==2)
                {
                    System.out.print("k" + " "); //Prints out a black king piece.
                }
                else if (Board[r][c].isBlack()==true && Board[r][c].getType()==3)
                {
                    System.out.print("b" + " "); //Prints out a black king piece.
                }
                else if (Board[r][c].isBlack()==true && Board[r][c].getType()==4)
                {
                    System.out.print("q" + " "); //Prints out a black king piece.
                }
                else if (Board[r][c].isBlack()==true && Board[r][c].getType()==5)
                {
                    System.out.print("x" + " "); //Prints out a black king piece.
                }
                else if (Board[r][c].isBlack()==false && Board[r][c].getType()==0)
                {
                    System.out.print("P" + " "); //Prints out a black king piece.
                }
                else if (Board[r][c].isBlack()==false && Board[r][c].getType()==1)
                {
                    System.out.print("R" + " "); //Prints out a black king piece.
                }
                else if (Board[r][c].isBlack()==false && Board[r][c].getType()==2)
                {
                    System.out.print("K" + " "); //Prints out a black king piece.
                }
                else if (Board[r][c].isBlack()==false && Board[r][c].getType()==3)
                {
                    System.out.print("B" + " "); //Prints out a black king piece.
                }
                else if (Board[r][c].isBlack()==false && Board[r][c].getType()==4)
                {
                    System.out.print("Q" + " "); //Prints out a black king piece.
                }
                else if (Board[r][c].isBlack()==false && Board[r][c].getType()==5)
                {
                    System.out.print("X" + " "); //Prints out a black king piece.
                }


            }
            System.out.println();
        }
        if(isWhiteCheck==true)
        {
            System.out.println("White King is in check");
        }
        if(isBlackCheck==true)
        {
            System.out.println("Black King is in check");
        }
    }

    public boolean addPiece(int r, int c, ChessPiece obj)
    {
        if (r<boardLength && c<boardLength)
        {
            if (Board[r][c]==null)
            {
                Board[r][c] = obj;
                return true;
            }
            else
                return false;
        }
        else
            return false;
    }

    public boolean blackTurn()
    {
        return blackTurn;
    }

    public int length()
    {
        return boardLength;
    }

    public ChessPiece get(int row, int col)
    {
        return Board[row][col];
    }

    public boolean isWin()
    {
        return false;
    }

    public static int getBlackKingRow ()
    {
        return blackKingRow;
    }

    public static int getBlackKingCol ()
    {
        return blackKingCol;
    }

    public static int getWhiteKingRow ()
    {
        return whiteKingRow;
    }


    public static int getWhiteKingCol ()
    {
        return whiteKingCol;
    }

    public static void whiteKingSet(int row, int col)
    {
        whiteKingRow=row;
        whiteKingCol=col;
    }

    public static void blackKingSet(int row, int col)
    {
        blackKingRow=row;
        blackKingCol=col;
    }

    public void changeWhiteCheck ()
    {
        isWhiteCheck= !isWhiteCheck;
    }

    public static void setBoard (ChessPiece[][] pboard)
    {
        Board=pboard;
    }



    public boolean move(int fromRow, char fromCol, int toRow, char toCol)
    {
        int iFromCol=fromCol-97;
        int itoCol=toCol-97;
        int ifromRow=fromRow-49;
        int itoRow=toRow-49;
        ChessPiece[][] tempBoard = new ChessPiece[8][8];
        for(int c=0;c<tempBoard.length;c++)
        {
            for(int r=0;r<tempBoard.length;r++)
            {
                tempBoard[r][c]=Board[r][c];
            }
        }
        if(Board[7-ifromRow][iFromCol]==null)
        {
            return false;
        }
        else
        {
            if(iFromCol<8 && ifromRow<8 && itoRow<8 && 0<=iFromCol && 0<=ifromRow && 0<=itoRow )
            {
                if(Board[7-ifromRow][iFromCol].getType()==0)
                {


                    if(Pawn.pawnMove(ifromRow, fromCol, itoRow, toCol, Board, blackTurn)==true)
                    {
                        if(isWhiteCheck==true || isBlackCheck==true)
                        {
                            if(isWhiteCheck==true && blackTurn==false)
                            {
                                if(kingCheck.checkMove(Board, blackTurn)==true)
                                {
                                    System.out.println("Invalid Move. White King is still in check.");
                                    Board=tempBoard;
                                    return false;
                                }
                                else
                                {
                                    isWhiteCheck=false;
                                    blackTurn=!blackTurn;
                                    return true;
                                }
                            }
                            else
                            {
                                if(isBlackCheck==true && blackTurn==true)
                                {
                                    if(kingCheck.checkMove(Board, blackTurn)==true)
                                    {
                                        System.out.println("Invalid Move. Black King is Still in check.");
                                        Board=tempBoard;
                                        return false;
                                    }
                                    else
                                    {
                                        isBlackCheck=false;
                                        blackTurn=!blackTurn;
                                        return true;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if(isWhiteCheck==false && blackTurn==true)
                            {
                                if(kingCheck.checkMove(Board, blackTurn)==true)
                                {
                                    isWhiteCheck=true;
                                }

                            }
                            else
                            {
                                if(isBlackCheck==false && blackTurn==false)
                                {
                                    if(kingCheck.checkMove(Board, blackTurn)==true)
                                    {
                                        System.out.println("hi1");
                                        isBlackCheck=true;
                                    }
                                }
                            }
                        }
                    }

                    blackTurn=!blackTurn;
                    return true;
                }

                if(Board[7-ifromRow][iFromCol].getType()==1)
                {
                    if(Rook.rookMove(ifromRow, fromCol, itoRow, toCol, Board, blackTurn)==true)
                    {
                        if(isWhiteCheck==true || isBlackCheck==true)
                        {
                            if(isWhiteCheck==true && blackTurn==false)
                            {
                                if(kingCheck.checkMove(Board, blackTurn)==true)
                                {
                                    System.out.println("Invalid Move. White King is still in check.");
                                    Board=tempBoard;
                                    return false;
                                }
                                else
                                {
                                    isWhiteCheck=false;
                                    blackTurn=!blackTurn;
                                    return true;
                                }
                            }
                            else
                            {
                                if(isBlackCheck==true && blackTurn==true)
                                {
                                    if(kingCheck.checkMove(Board, blackTurn)==true)
                                    {
                                        System.out.println("Invalid Move. Black King is Still in check.");
                                        Board=tempBoard;
                                        return false;
                                    }
                                    else
                                    {
                                        isBlackCheck=false;
                                        blackTurn=!blackTurn;
                                        return true;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if(isWhiteCheck==false && blackTurn==true)
                            {
                                if(kingCheck.checkMove(Board, blackTurn)==true)
                                {
                                    isWhiteCheck=true;
                                }
                            }
                            else
                            {
                                if(isBlackCheck==false && blackTurn==false)
                                {
                                    if(kingCheck.checkMove(Board, blackTurn)==true)
                                    {
                                        System.out.println("hi1");
                                        isBlackCheck=true;
                                    }
                                }
                            }
                        }
                    }
                    blackTurn=!blackTurn;
                    return true;
                }

                if(Board[7-ifromRow][iFromCol].getType()==2)
                {
                    if(Knight.knightMove(ifromRow, fromCol, itoRow, toCol, Board, blackTurn)==true)
                    {
                        if(isWhiteCheck==true || isBlackCheck==true)
                        {
                            if(isWhiteCheck==true && blackTurn==false)
                            {
                                if(kingCheck.checkMove(Board, blackTurn)==true)
                                {
                                    System.out.println("Invalid Move. White King is still in check.");
                                    Board=tempBoard;
                                    return false;
                                }
                                else
                                {
                                    isWhiteCheck=false;
                                    blackTurn=!blackTurn;
                                    return true;
                                }
                            }
                            else
                            {
                                if(isBlackCheck==true && blackTurn==true)
                                {
                                    if(kingCheck.checkMove(Board, blackTurn)==true)
                                    {
                                        System.out.println("Invalid Move. Black King is Still in check.");
                                        Board=tempBoard;
                                        return false;
                                    }
                                    else
                                    {
                                        isBlackCheck=false;
                                        blackTurn=!blackTurn;
                                        return true;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if(isWhiteCheck==false && blackTurn==true)
                            {
                                if(kingCheck.checkMove(Board, blackTurn)==true)
                                {
                                    isWhiteCheck=true;
                                }
                            }
                            else
                            {
                                if(isBlackCheck==false && blackTurn==false)
                                {
                                    if(kingCheck.checkMove(Board, blackTurn)==true)
                                    {
                                        System.out.println("hi1");
                                        isBlackCheck=true;
                                    }
                                }
                            }
                        }
                    }
                    blackTurn=!blackTurn;
                    return true;
                }

                if(Board[7-ifromRow][iFromCol].getType()==3)
                {
                    if(Bishop.bishopMove(ifromRow, fromCol, itoRow, toCol, Board, blackTurn)==true)
                    {
                        if(isWhiteCheck==true || isBlackCheck==true)
                        {
                            if(isWhiteCheck==true && blackTurn==false)
                            {
                                if(kingCheck.checkMove(Board, blackTurn)==true)
                                {
                                    System.out.println("Invalid Move. White King is still in check.");
                                    Board=tempBoard;
                                    return false;
                                }
                                else
                                {
                                    isWhiteCheck=false;
                                    blackTurn=!blackTurn;
                                    return true;
                                }
                            }
                            else
                            {
                                if(isBlackCheck==true && blackTurn==true)
                                {
                                    if(kingCheck.checkMove(Board, blackTurn)==true)
                                    {
                                        System.out.println("Invalid Move. Black King is Still in check.");
                                        Board=tempBoard;
                                        return false;
                                    }
                                    else
                                    {
                                        isBlackCheck=false;
                                        blackTurn=!blackTurn;
                                        return true;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if(isWhiteCheck==false && blackTurn==true)
                            {
                                if(kingCheck.checkMove(Board, blackTurn)==true)
                                {
                                    isWhiteCheck=true;
                                }
                            }
                            else
                            {
                                if(isBlackCheck==false && blackTurn==false)
                                {
                                    if(kingCheck.checkMove(Board, blackTurn)==true)
                                    {
                                        System.out.println("hi1");
                                        isBlackCheck=true;
                                    }
                                }
                            }
                        }
                    }
                    blackTurn=!blackTurn;
                    return true;
                }

                if(Board[7-ifromRow][iFromCol].getType()==4)
                {
                    System.out.println(blackTurn);
                    if(Queen.queenMove(ifromRow, fromCol, itoRow, toCol, Board, blackTurn)==true)
                    {
                        if(isWhiteCheck==true || isBlackCheck==true)
                        {
                            if(isWhiteCheck==true && blackTurn==false)
                            {
                                if(kingCheck.checkMove(Board, blackTurn)==true)
                                {
                                    System.out.println("Invalid Move. White King is still in check.");
                                    Board=tempBoard;
                                    return false;
                                }
                                else
                                {
                                    isWhiteCheck=false;
                                    blackTurn=!blackTurn;
                                    return true;
                                }
                            }
                            else
                            {
                                if(isBlackCheck==true && blackTurn==true)
                                {
                                    if(kingCheck.checkMove(Board, blackTurn)==true)
                                    {
                                        System.out.println("Invalid Move. Black King is Still in check.");
                                        Board=tempBoard;
                                        return false;
                                    }
                                    else
                                    {
                                        isBlackCheck=false;
                                        blackTurn=!blackTurn;
                                        return true;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if(isWhiteCheck==false && blackTurn==true)
                            {
                                if(kingCheck.checkMove(Board, blackTurn)==false)
                                {
                                    isWhiteCheck=true;
                                }
                            }
                            else
                            {
                                if(isBlackCheck==false && blackTurn==false)
                                {
                                    if(kingCheck.checkMove(Board, blackTurn)==false)
                                    {
                                        System.out.println("hi1");
                                        isBlackCheck=true;
                                    }
                                }
                            }
                        }
                    }

                    blackTurn=!blackTurn;
                    return true;
                }

                if(Board[7-ifromRow][iFromCol].getType()==5)
                {
                    if(King.kingMove(ifromRow, fromCol, itoRow, toCol, Board, blackTurn)==true)
                    {
                        if(isWhiteCheck==true || isBlackCheck==true)
                        {
                            if(isWhiteCheck==true && blackTurn==false)
                            {
                                if(kingCheck.checkMove(Board, blackTurn)==true)
                                {
                                    System.out.println("Invalid Move. White King is still in check.");
                                    Board=tempBoard;
                                    return false;
                                }
                                else
                                {
                                    isWhiteCheck=false;
                                    blackTurn=!blackTurn;
                                    return true;
                                }
                            }
                            else
                            {
                                if(isBlackCheck==true && blackTurn==true)
                                {
                                    if(kingCheck.checkMove(Board, blackTurn)==true)
                                    {
                                        System.out.println("Invalid Move. Black King is Still in check.");
                                        Board=tempBoard;
                                        return false;
                                    }
                                    else
                                    {
                                        isBlackCheck=false;
                                        blackTurn=!blackTurn;
                                        return true;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if(isWhiteCheck==false && blackTurn==true)
                            {
                                if(kingCheck.checkMove(Board, blackTurn)==true)
                                {
                                    isWhiteCheck=true;
                                }
                            }
                            else
                            {
                                if(isBlackCheck==false && blackTurn==false)
                                {
                                    if(kingCheck.checkMove(Board, blackTurn)==true)
                                    {
                                        System.out.println("hi1");
                                        isBlackCheck=true;
                                    }
                                }
                            }
                        }
                    }
                    blackTurn=!blackTurn;
                    return true;
                }
            }
        }
        return false;

    }

    public static boolean checkCheckmate()
    {
        if(kingCheck.checkmate(Board, blackTurn))
        {
            return true;
        }
        else
            return false;
    }

    //public static boolean checkStalemate()
    {
        if(isWhiteCheck==false)
        {
            //if(all possible moves put the opposing king in check)
            //return true
            //else{
            //return false}
        }
        else
        {
            if(isBlackCheck==false)
            {
                //if(all possible moves put the opposing king in check)
                //return true
                //else{
                //return false}
            }
            else
            {
                //Not sure how to implement a counter, I cannot find or locate where any change is
                //happening on the board when pieces are moved. The piece counters that are instantiated
                //(blackCount and whiteCount) aren't used and I can't find where in the code to find them.
            }
        }//we DO NOT need to ask if players want to draw.
    }
}







