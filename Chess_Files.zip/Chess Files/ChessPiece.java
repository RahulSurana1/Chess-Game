public class ChessPiece
{
    private int row;
    private int col;
    private boolean black;
    private int pieceType;

    public ChessPiece(int nRow, int nCol, boolean blackTeam, int type)
    {
        super();
        row=nRow;
        col=nCol;
        black=blackTeam;
        pieceType=type;
    }

    public int getRow()
    {
        return row;
    }

    public int getCol()
    {
        return col;
    }

    public void setRow(int newRow)
    {
        this.row=newRow;
    }

    public void setCol(int newCol)
    {
        this.col=newCol;
    }

    public boolean isBlack()
    {
        return this.black;
    }

    public int getType()
    {
        return pieceType;
    }

}




