public class Queen extends ChessPiece
{
    public Queen(int nRow, int nCol, boolean black)
    {
        super(nRow, nCol, black, 4);
    }

    public static boolean queenMove (int fromRow, char fromCol, int toRow, char toCol, ChessPiece[][] Board, boolean turn)
    {
        int iFromCol= fromCol-97;
        int iToCol= toCol-97;
        toRow=7-toRow;
        fromRow=7-fromRow;

        if(Board[fromRow][iFromCol].isBlack()==turn)
        {
            if(queenValidMove(fromRow, iFromCol, toRow, iToCol, Board, turn))
            {
                if(Board[toRow][iToCol]!=null)
                {
                    if(Board[fromRow][iFromCol].isBlack()!=Board[toRow][iToCol].isBlack())
                    {
                        Queen temp = new Queen(toRow, iToCol, Board[fromRow][iFromCol].isBlack());
                        Board[fromRow][iFromCol]= null;
                        Board[toRow][iToCol]=temp;
                        turn=!turn;
                        return true;
                    }
                    else
                        return false;
                }
                else
                {
                    Queen temp = new Queen(toRow, iToCol, Board[fromRow][iFromCol].isBlack());
                    Board[fromRow][iFromCol]= null;
                    Board[toRow][iToCol]=temp;
                    turn=!turn;
                    return true;
                }

            }
        }
        return false;
    }

    public static boolean queenValidMove(int fromRow, int fromCol, int toRow, int toCol, ChessPiece[][] Board, boolean turn)
    {
        boolean valid = true;
        int col=toCol;

        if(Board[fromRow][fromCol]==null)
        {
            return false;
        }
        //Determines if it moves straight
        else
        {
            if(fromRow == toRow || fromCol == toCol)
            {
                if(Board[fromRow][fromCol].getType()==4)
                {
                    if(toRow-fromRow!=0 && toCol-fromCol!=0)
                    {
                        return false;
                    }
                    else
                    {
                        if(toRow-fromRow!=0)
                        {
                            if(toRow>fromRow)
                            {
                                for(int i=fromRow+1;i<toRow; i++)
                                {
                                    if(Board[i][fromCol]!=null)
                                    {
                                        return false;
                                    }
                                }
                                return true;

                            }
                            else
                            {
                                if(toRow<fromRow)
                                {
                                    for(int i=toRow-1;i>fromRow; i--)
                                    {
                                        if(Board[i][fromCol]!=null)
                                        {
                                            return false;
                                        }
                                    }
                                    return true;
                                }
                            }
                        }
                        else
                        {
                            if(toCol-fromCol!=0)
                            {
                                if(toCol>fromCol)
                                {
                                    for(int i=fromCol+1;i<toCol; i++)
                                    {
                                        if(Board[fromRow][i]!=null)
                                        {
                                            return false;
                                        }
                                    }
                                    return true;

                                }
                                else
                                {
                                    if(toCol<fromCol)
                                    {
                                        for(int i=toCol-1;i>fromCol; i--)
                                        {
                                            if(Board[fromRow][i]!=null)
                                            {
                                                return false;
                                            }
                                        }
                                        return true;

                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    return false;
                }
            }
            else
            {
                if(Math.abs(fromRow-toRow) == Math.abs(fromCol-toCol))
                {
                    if(fromRow>toRow)
                    {
                        if(fromCol>toCol)
                        {
                            for(int row=toRow; row<fromRow; row++)
                            {
                                System.out.println(Board[fromRow][fromCol].isBlack());
                                System.out.println(Board[toRow][toCol].isBlack());
                                if (Board[row][col] == null)
                                {
                                    col++;
                                }
                                else
                                {
                                    if(row==toRow && col==toCol)
                                    {
                                        if(Board[fromRow][fromCol].isBlack() != Board[toRow][toCol].isBlack())
                                        {
                                            col++;
                                        }
                                    }
                                    else
                                    {
                                        return false;
                                    }
                                }

                            }
                            return true;
                        }
                        else
                        {
                            if(fromCol<toCol)
                            {
                                for(int row=toRow; row<fromRow; row++)
                                {
                                    if (Board[row][col] == null)
                                    {
                                        valid = true;
                                        col--;
                                    }
                                    else
                                    {
                                        if(row==toRow && col==toCol)
                                        {
                                            if(Board[fromRow][fromCol].isBlack() != Board[toRow][toCol].isBlack())
                                            {
                                                valid = true;
                                                col--;
                                            }
                                        }
                                        else
                                        {
                                            return false;
                                        }
                                    }
                                }
                                return valid;
                            }
                        }
                    }
                    else
                    {
                        if(fromRow<toRow)
                        {
                            if(fromCol>toCol)
                            {
                                for(int row=toRow; row>fromRow; row--)
                                {
                                    if (Board[row][col] == null)
                                    {
                                        valid = true;
                                        col++;
                                    }
                                    else
                                    {
                                        if(row==toRow && col==toCol)
                                        {
                                            if(Board[fromRow][fromCol].isBlack() != Board[toRow][toCol].isBlack())
                                            {
                                                valid = true;
                                                col++;
                                            }
                                        }
                                        else
                                        {
                                            return false;
                                        }
                                    }
                                }
                                return valid;
                            }
                            if(fromCol<toCol)
                            {
                                for(int row=toRow; row>fromRow; row--)
                                {
                                    if (Board[row][col] == null)
                                    {
                                        valid = true;
                                        col--;
                                    }
                                    else
                                    {
                                        if(row==toRow && col==toCol)
                                        {
                                            if(Board[toRow][toCol].isBlack() != Board[fromRow][fromCol].isBlack())
                                            {
                                                valid = true;
                                                col--;
                                            }
                                        }
                                        else
                                        {
                                            System.out.println(Board[row][col]);
                                            System.out.println(row);
                                            System.out.println(col);
                                            return false;
                                        }
                                    }
                                }
                                return valid;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }
}







