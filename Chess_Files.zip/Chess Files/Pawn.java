
public class Pawn extends ChessPiece
{

    public Pawn(int nRow, int nCol, boolean black)
    {
        super(nRow, nCol, black, 0);
    }

    public static boolean pawnValidMove(int fromRow, int fromCol, int toRow, int toCol, ChessPiece[][] Board, boolean turn)
    {

        if(Board[fromRow][fromCol]==null)
        {
            return false;
        }
        else
        {
            if(Math.abs(toRow-fromRow)!=1)
            {
                if (Math.abs(toRow-fromRow)==2)
                {
                    if(Board[fromRow][fromCol].isBlack()==true && fromRow==1)
                    {
                        if(Board[toRow][toCol]==null && Board[toRow-1][toCol]==null)
                        {
                            return true;
                        }
                    }
                    else
                    {
                        if(Board[fromRow][fromCol].isBlack()==false && fromRow==6)
                        {
                            if(Board[toRow][toCol]==null && Board[toRow+1][toCol]==null)
                            {
                                return true;
                            }
                        }
                    }
                }
                else
                    return false;
            }
            else
            {
                if (Math.abs(toCol-fromCol)==1)
                {
                    if(pawnJump(fromRow, fromCol, toRow, toCol, Board, turn))
                    {
                        return true;
                    }
                }
                else
                {
                    if(Board[toRow][toCol]==null)
                    {
                        return true;
                    }
                    else
                        return false;
                }
            }
        }
        return false;
    }

    public static boolean pawnJump(int fromRow, int fromCol, int toRow, int toCol, ChessPiece[][] Board, boolean turn)
    {
        if(Board[toRow][toCol]==null)
        {
            return false;
        }
        else
        {
            if(Board[fromRow][fromCol].isBlack()==Board[toRow][toCol].isBlack())
            {
                return false;
            }
            else
            {
                if(Board[fromRow][fromCol].isBlack() && turn==true)
                {
                    if(fromRow-toRow==-1)
                    {
                        Board[toRow][toCol]=null;
                        Pawn temp= new Pawn(toRow, toCol, true);
                        Board[toRow][toCol]=temp;
                        return true;
                    }
                }
                else
                {
                    if(Board[fromRow][fromCol].isBlack()==false && turn==false)
                    {
                        if(fromRow-toRow==1)
                        {
                            Board[toRow][toCol]=null;
                            Pawn temp= new Pawn(toRow, toCol, false);
                            Board[toRow][toCol]=temp;
                            return true;
                        }
                    }
                }
                return false;
            }
        }
    }

    public static boolean pawnMove(int fromRow, char fromCol, int toRow, char toCol, ChessPiece[][] Board, boolean turn)
    {
        int iFromCol= fromCol-97;
        int iToCol= toCol-97;
        toRow=7-toRow;
        fromRow=7-fromRow;

        if (turn==true && Board[fromRow][iFromCol].isBlack()==true)
        {
            if(pawnValidMove(fromRow, iFromCol, toRow, iToCol, Board, turn)==true)
            {
                Pawn temp = new Pawn(toRow, iToCol, true);
                Board[fromRow][iFromCol]= null;
                Board[toRow][iToCol]=temp;
                turn=false;
                return true;
            }
        }
        else
        {
            if(turn== false && Board[fromRow][iFromCol].isBlack()==false)
            {
                if(pawnValidMove(fromRow, iFromCol, toRow, iToCol, Board, turn)==true)
                {
                    Pawn temp = new Pawn(toRow, iToCol, false);
                    Board[fromRow][iFromCol]= null;
                    Board[toRow][iToCol]=temp;
                    turn=true;
                    return true;
                }
            }
        }
        return false;
    }

}













