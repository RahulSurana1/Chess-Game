
public class Rook extends ChessPiece
{
    public Rook(int nRow, int nCol, boolean black)
    {
        super(nRow, nCol, black, 1);
    }

    public static boolean rookMove (int fromRow, char fromCol, int toRow, char toCol, ChessPiece[][] Board, boolean turn)
    {
        int iFromCol= fromCol-97;
        int iToCol= toCol-97;
        toRow=7-toRow;
        fromRow=7-fromRow;

        if(Board[fromRow][iFromCol].isBlack()==turn)
        {
            if(rookValidMove(fromRow, iFromCol, toRow, iToCol, Board, turn))
            {
                if(Board[toRow][iToCol]!=null)
                {
                    if(Board[fromRow][iFromCol].isBlack()!=Board[toRow][iToCol].isBlack())
                    {
                        Rook temp = new Rook(toRow, iToCol, Board[fromRow][iFromCol].isBlack());
                        Board[fromRow][iFromCol]= null;
                        Board[toRow][iToCol]=temp;
                        turn=!turn;
                        return true;
                    }
                    else
                        return false;
                }
                else
                {
                    Rook temp = new Rook(toRow, iToCol, Board[fromRow][iFromCol].isBlack());
                    Board[fromRow][iFromCol]= null;
                    Board[toRow][iToCol]=temp;
                    turn=!turn;
                    return true;
                }

            }
        }
        return false;
    }

    public static boolean rookValidMove (int fromRow, int fromCol, int toRow, int toCol, ChessPiece[][] Board, boolean turn)
    {
        if(Board[fromRow][fromCol]==null)
        {
            return false;
        }
        else
        {
            if(Board[fromRow][fromCol].getType()==1)
            {
                if(toRow-fromRow!=0 && toCol-fromCol!=0)
                {
                    return false;
                }
                else
                {
                    if(toRow-fromRow!=0)
                    {
                        if(toRow>fromRow)
                        {
                            for(int i=fromRow+1;i<toRow; i++)
                            {
                                if(Board[i][fromCol]!=null)
                                {
                                    return false;
                                }
                            }
                            return true;

                        }
                        else
                        {
                            if(toRow<fromRow)
                            {
                                for(int i=toRow-1;i>fromRow; i--)
                                {
                                    if(Board[i][fromCol]!=null)
                                    {
                                        return false;
                                    }
                                }
                                return true;
                            }
                        }
                    }
                    else
                    {
                        if(toCol-fromCol!=0)
                        {
                            if(toCol>fromCol)
                            {
                                for(int i=fromCol+1;i<toCol; i++)
                                {
                                    if(Board[fromRow][i]!=null)
                                    {
                                        return false;
                                    }
                                }
                                return true;

                            }
                            else
                            {
                                if(toCol<fromCol)
                                {
                                    for(int i=toCol-1;i>fromCol; i--)
                                    {
                                        if(Board[fromRow][i]!=null)
                                        {
                                            return false;
                                        }
                                    }
                                    return true;

                                }
                            }
                        }
                    }
                }
            }
            else
                return false;

        }
        return false;
    }

}





