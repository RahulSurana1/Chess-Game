
public class kingCheck
{
    public static boolean check (int toRow, int toCol, ChessPiece[][] Board, boolean blackTurn)
    {
        if(blackTurn==false || (ChessBoard.isWhiteCheck==true))
        {
            if(Board[toRow][toCol].getType()==0)
            {
                if(Pawn.pawnValidMove(toRow, toCol, ChessBoard.getBlackKingRow()-1, ChessBoard.getBlackKingCol()-1, Board, blackTurn)==true)
                {
                    return true;
                }
                else
                    return false;
            }

            if(Board[toRow][toCol].getType()==1)
            {
                if(Rook.rookValidMove(toRow, toCol, ChessBoard.getBlackKingRow()-1, ChessBoard.getBlackKingCol()-1, Board, blackTurn)==true)
                {

                    return true;
                }
                else
                    return false;
            }

            if(Board[toRow][toCol].getType()==2)
            {
                if(Knight.KnightValidMove(toRow, toCol, ChessBoard.getBlackKingRow()-1, ChessBoard.getBlackKingCol()-1, Board, blackTurn)==true)
                {
                    return true;
                }
                else
                    return false;
            }

            if(Board[toRow][toCol].getType()==3)
            {
                if(Bishop.bishopValidMove(toRow, toCol, ChessBoard.getBlackKingRow()-1, ChessBoard.getBlackKingCol()-1, Board, blackTurn)==true)
                {

                    return true;
                }
                else
                    return false;
            }

            if(Board[toRow][toCol].getType()==4)
            {
                System.out.println(toRow);
                System.out.println(toCol);
                if(Queen.queenValidMove(toRow, toCol, ChessBoard.getBlackKingRow()-1, ChessBoard.getBlackKingCol()-1, Board, blackTurn)==true)
                {
                    return true;
                }
                else
                    return false;
            }

            if(Board[toRow][toCol].getType()==5)
            {
                if(King.kingValidMove(toRow, toCol, ChessBoard.getBlackKingRow()-1, ChessBoard.getBlackKingCol()-1, Board, blackTurn)==true)
                {

                    return true;
                }
                else
                    return false;
            }
            return false;
        }
        else
        {
            if(Board[toRow][toCol].getType()==0)
            {
                if(Pawn.pawnValidMove(toRow, toCol, ChessBoard.getWhiteKingRow()-1, ChessBoard.getWhiteKingCol()-1, Board, blackTurn)==true)
                {

                    return true;
                }
                else
                    return false;
            }

            if(Board[toRow][toCol].getType()==1)
            {
                if(Rook.rookValidMove(toRow, toCol, ChessBoard.getWhiteKingRow()-1, ChessBoard.getWhiteKingCol()-1, Board, blackTurn)==true)
                {

                    return true;
                }
                else
                    return false;
            }

            if(Board[toRow][toCol].getType()==2)
            {
                if(Knight.KnightValidMove(toRow, toCol, ChessBoard.getWhiteKingRow()-1, ChessBoard.getWhiteKingCol()-1, Board, blackTurn)==true)
                {

                    return true;
                }
                else
                    return false;
            }

            if(Board[toRow][toCol].getType()==3)
            {
                if(Bishop.bishopValidMove(toRow, toCol, ChessBoard.getWhiteKingRow()-1, ChessBoard.getWhiteKingCol()-1, Board, blackTurn)==true)
                {

                    return true;
                }
                else
                    return false;
            }

            if(Board[toRow][toCol].getType()==4)
            {
                if(Queen.queenValidMove(toRow, toCol, ChessBoard.getWhiteKingRow()-1, ChessBoard.getWhiteKingCol()-1, Board, blackTurn)==true)
                {
                    return true;
                }
                else
                    return false;
            }

            if(Board[toRow][toCol].getType()==5)
            {
                if(King.kingValidMove(toRow, toCol, ChessBoard.getWhiteKingRow()-1, ChessBoard.getWhiteKingCol()-1, Board, blackTurn)==true)
                {
                    return true;
                }
                else
                    return false;
            }
            return false;
        }

    }

    public static boolean checkMove (ChessPiece[][] Board, boolean turn)
    {
        if(turn==true)
        {
            for(int c=0; c<Board.length; c++)
            {
                for(int r=0; r<Board.length; r++)
                {
                    if(Board[r][c]!=null)
                    {
                        if(check(r, c, Board ,turn)==true)
                        {
                            return false;
                        }
                    }
                }
            }
            return false;
        }
        else
        {
            for(int c=0; c<Board.length; c++)
            {
                for(int r=0; r<Board.length; r++)
                {
                    if(Board[r][c]!=null)
                    {
                        if(check(r, c, Board ,turn)==true)
                        {
                            return false;
                        }
                    }
                }
            }
            return false;
        }
    }


    public static boolean checkmate (ChessPiece[][] Board, boolean turn)
    {
        for(int c=0;c<Board.length;c++)
        {
            for(int r=0;r<Board.length;r++)
            {
                if(ChessBoard.isBlackCheck==true && turn==true)
                {
                    if(Board[r][c]==null)
                    {

                    }
                    else
                    {
                        if(Board[r][c].isBlack()==true)
                        {
                            for(int ci=0;ci<Board.length;ci++)
                            {
                                for(int ri=0;ri<Board.length;ri++)
                                {
                                    if(Board[r][c].getType()==0)
                                    {
                                        if(Pawn.pawnValidMove(r, c, ri, ci, Board, turn)==true)
                                        {
                                            if(Board[ri][ci]==null)
                                            {
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                Board[r][c]=Board[ri][ci];
                                            }
                                            else
                                            {
                                                ChessPiece[][] tempBoard = new ChessPiece[8][8];
                                                for(int i=0;i<tempBoard.length;i++)
                                                {
                                                    for(int j=0;j<tempBoard.length;j++)
                                                    {
                                                        tempBoard[i][j]=Board[i][j];
                                                    }
                                                }
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                ChessBoard.setBoard(tempBoard);
                                            }

                                            return true;
                                        }
                                    }

                                    if(Board[r][c].getType()==1)
                                    {
                                        if(Rook.rookValidMove(r, c, ri, ci, Board, turn)==true)
                                        {
                                            if(Board[ri][ci]==null)
                                            {
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                Board[r][c]=Board[ri][ci];
                                            }
                                            else
                                            {
                                                ChessPiece[][] tempBoard = new ChessPiece[8][8];
                                                for(int i=0;i<tempBoard.length;i++)
                                                {
                                                    for(int j=0;j<tempBoard.length;j++)
                                                    {
                                                        tempBoard[i][j]=Board[i][j];
                                                    }
                                                }
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                ChessBoard.setBoard(tempBoard);
                                            }

                                            return true;
                                        }
                                    }

                                    if(Board[r][c].getType()==2)
                                    {
                                        if(Knight.KnightValidMove(r, c, ri, ci, Board, turn)==true)
                                        {
                                            if(Board[ri][ci]==null)
                                            {
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                Board[r][c]=Board[ri][ci];
                                            }
                                            else
                                            {
                                                ChessPiece[][] tempBoard = new ChessPiece[8][8];
                                                for(int i=0;i<tempBoard.length;i++)
                                                {
                                                    for(int j=0;j<tempBoard.length;j++)
                                                    {
                                                        tempBoard[i][j]=Board[i][j];
                                                    }
                                                }
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                ChessBoard.setBoard(tempBoard);
                                            }

                                            return true;
                                        }
                                    }

                                    if(Board[r][c].getType()==3)
                                    {
                                        if(Bishop.bishopValidMove(r, c, ri, ci, Board, turn)==true)
                                        {
                                            if(Board[ri][ci]==null)
                                            {
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                Board[r][c]=Board[ri][ci];
                                            }
                                            else
                                            {
                                                ChessPiece[][] tempBoard = new ChessPiece[8][8];
                                                for(int i=0;i<tempBoard.length;i++)
                                                {
                                                    for(int j=0;j<tempBoard.length;j++)
                                                    {
                                                        tempBoard[i][j]=Board[i][j];
                                                    }
                                                }
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                ChessBoard.setBoard(tempBoard);
                                            }

                                            return true;
                                        }
                                    }

                                    if(Board[r][c].getType()==4)
                                    {
                                        if(Queen.queenValidMove(r, c, ri, ci, Board, turn)==true)
                                        {
                                            if(Board[ri][ci]==null)
                                            {
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                Board[r][c]=Board[ri][ci];
                                            }
                                            else
                                            {
                                                ChessPiece[][] tempBoard = new ChessPiece[8][8];
                                                for(int i=0;i<tempBoard.length;i++)
                                                {
                                                    for(int j=0;j<tempBoard.length;j++)
                                                    {
                                                        tempBoard[i][j]=Board[i][j];
                                                    }
                                                }
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                ChessBoard.setBoard(tempBoard);
                                            }

                                            return true;
                                        }
                                    }

                                    if(Board[r][c].getType()==5)
                                    {
                                        if(King.kingValidMove(r, c, ri, ci, Board, turn)==true)
                                        {
                                            if(Board[ri][ci]==null)
                                            {
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                Board[r][c]=Board[ri][ci];
                                            }
                                            else
                                            {
                                                ChessPiece[][] tempBoard = new ChessPiece[8][8];
                                                for(int i=0;i<tempBoard.length;i++)
                                                {
                                                    for(int j=0;j<tempBoard.length;j++)
                                                    {
                                                        tempBoard[i][j]=Board[i][j];
                                                    }
                                                }
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                ChessBoard.setBoard(tempBoard);
                                            }

                                            return true;
                                        }
                                    }
                                    return false;
                                }
                            }
                        }
                    }
                }
                if(ChessBoard.isWhiteCheck==true && turn==false)
                {
                    if(Board[r][c]==null)
                    {

                    }
                    else
                    {
                        if(Board[r][c].isBlack()==false)
                        {
                            for(int ci=0;ci<Board.length;ci++)
                            {
                                for(int ri=0;ri<Board.length;ri++)
                                {
                                    if(Board[r][c].getType()==0)
                                    {
                                        if(Pawn.pawnValidMove(r, c, ri, ci, Board, turn)==true)
                                        {
                                            if(Board[ri][ci]==null)
                                            {
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                Board[r][c]=Board[ri][ci];
                                            }
                                            else
                                            {
                                                ChessPiece[][] tempBoard = new ChessPiece[8][8];
                                                for(int i=0;i<tempBoard.length;i++)
                                                {
                                                    for(int j=0;j<tempBoard.length;j++)
                                                    {
                                                        tempBoard[i][j]=Board[i][j];
                                                    }
                                                }
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                ChessBoard.setBoard(tempBoard);
                                            }

                                            return true;
                                        }
                                    }

                                    if(Board[r][c].getType()==1)
                                    {
                                        if(Rook.rookValidMove(r, c, ri, ci, Board, turn)==true)
                                        {
                                            if(Board[ri][ci]==null)
                                            {
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                Board[r][c]=Board[ri][ci];
                                            }
                                            else
                                            {
                                                ChessPiece[][] tempBoard = new ChessPiece[8][8];
                                                for(int i=0;i<tempBoard.length;i++)
                                                {
                                                    for(int j=0;j<tempBoard.length;j++)
                                                    {
                                                        tempBoard[i][j]=Board[i][j];
                                                    }
                                                }
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                ChessBoard.setBoard(tempBoard);
                                            }

                                            return true;
                                        }
                                    }

                                    if(Board[r][c].getType()==2)
                                    {
                                        if(Knight.KnightValidMove(r, c, ri, ci, Board, turn)==true)
                                        {
                                            if(Board[ri][ci]==null)
                                            {
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                Board[r][c]=Board[ri][ci];
                                            }
                                            else
                                            {
                                                ChessPiece[][] tempBoard = new ChessPiece[8][8];
                                                for(int i=0;i<tempBoard.length;i++)
                                                {
                                                    for(int j=0;j<tempBoard.length;j++)
                                                    {
                                                        tempBoard[i][j]=Board[i][j];
                                                    }
                                                }
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                ChessBoard.setBoard(tempBoard);
                                            }

                                            return true;
                                        }
                                    }

                                    if(Board[r][c].getType()==3)
                                    {
                                        if(Bishop.bishopValidMove(r, c, ri, ci, Board, turn)==true)
                                        {
                                            if(Board[ri][ci]==null)
                                            {
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                Board[r][c]=Board[ri][ci];
                                            }
                                            else
                                            {
                                                ChessPiece[][] tempBoard = new ChessPiece[8][8];
                                                for(int i=0;i<tempBoard.length;i++)
                                                {
                                                    for(int j=0;j<tempBoard.length;j++)
                                                    {
                                                        tempBoard[i][j]=Board[i][j];
                                                    }
                                                }
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                ChessBoard.setBoard(tempBoard);
                                            }

                                            return true;
                                        }
                                    }

                                    if(Board[r][c].getType()==4)
                                    {
                                        if(Queen.queenValidMove(r, c, ri, ci, Board, turn)==true)
                                        {
                                            if(Board[ri][ci]==null)
                                            {
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                Board[r][c]=Board[ri][ci];
                                            }
                                            else
                                            {
                                                ChessPiece[][] tempBoard = new ChessPiece[8][8];
                                                for(int i=0;i<tempBoard.length;i++)
                                                {
                                                    for(int j=0;j<tempBoard.length;j++)
                                                    {
                                                        tempBoard[i][j]=Board[i][j];
                                                    }
                                                }
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                ChessBoard.setBoard(tempBoard);
                                            }

                                            return true;
                                        }
                                    }

                                    if(Board[r][c].getType()==5)
                                    {
                                        if(King.kingValidMove(r, c, ri, ci, Board, turn)==true)
                                        {
                                            if(Board[ri][ci]==null)
                                            {
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                Board[r][c]=Board[ri][ci];
                                            }
                                            else
                                            {
                                                ChessPiece[][] tempBoard = new ChessPiece[8][8];
                                                for(int i=0;i<tempBoard.length;i++)
                                                {
                                                    for(int j=0;j<tempBoard.length;j++)
                                                    {
                                                        tempBoard[i][j]=Board[i][j];
                                                    }
                                                }
                                                Board[ri][ci]=Board[r][c];
                                                Board[r][c]=null;
                                                if(checkMove(Board, turn)==false)
                                                {
                                                    return false;
                                                }
                                                ChessBoard.setBoard(tempBoard);
                                            }

                                            return true;
                                        }
                                    }
                                    return false;
                                }
                            }
                        }
                    }

                }
            }

        }
        return false;
    }

}








