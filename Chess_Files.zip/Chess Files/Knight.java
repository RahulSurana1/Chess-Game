public class Knight extends ChessPiece
{
    public Knight(int nRow, int nCol, boolean black)
    {
        super(nRow, nCol, black, 2);
    }

    public static boolean KnightValidMove (int fromRow, int fromCol, int toRow, int toCol, ChessPiece[][] Board, boolean turn)
    {
        if(Board[fromRow][fromCol]==null)
        {
            return false;
        }
        else
        {
            if(turn==Board[fromRow][fromCol].isBlack())
            {
                if(toRow-fromRow==2 || toRow-fromRow==-2)
                {
                    if(toCol-fromCol==2 || toCol-fromCol==-2)
                    {
                        return false;
                    }
                    else
                    {
                        if(toCol-fromCol==1 || toCol-fromCol==-1)
                        {
                            if(Board[toRow][toCol]==null)
                            {
                                return true;
                            }
                            else
                            {
                                if(KnightJump(fromRow, fromCol, toRow, toCol, Board, turn))
                                    return true;
                                else
                                    return false;
                            }
                        }
                    }
                }
                else
                {
                    if(toCol-fromCol==2 || toCol-fromCol==-2)
                    {
                        if(toRow-fromRow==2 || toRow-fromRow==-2)
                        {
                            return false;
                        }
                        else
                        {
                            if(toRow-fromRow==1 || toRow-fromRow==-1)
                            {
                                if(Board[toRow][toCol]==null)
                                {
                                    return true;
                                }
                                else
                                {
                                    if(KnightJump(fromRow, fromCol, toRow, toCol, Board, turn))
                                    {
                                        return true;
                                    }
                                    else
                                        return false;
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }


    public static boolean KnightJump(int fromRow, int fromCol, int toRow, int toCol, ChessPiece[][] Board, boolean turn)
    {
        if(Board[toRow][toCol].isBlack()!=Board[fromRow][fromCol].isBlack())
        {
            Board[toRow][toCol]=null;
            Knight temp= new Knight(toRow, toCol, Board[fromRow][fromCol].isBlack());
            Board[toRow][toCol]=temp;
            return true;
        }
        else
            return false;
    }

    public static boolean knightMove(int fromRow, char fromCol, int toRow, char toCol, ChessPiece[][] Board, boolean turn)
    {
        int iFromCol= fromCol-97;
        int iToCol= toCol-97;
        toRow=7-toRow;
        fromRow=7-fromRow;
        System.out.println(toRow);
        System.out.println(fromRow);

        if (turn==true && Board[fromRow][iFromCol].isBlack()==true)
        {
            if(KnightValidMove(fromRow, iFromCol, toRow, iToCol, Board, turn)==true)
            {
                Knight temp = new Knight(toRow, iToCol, true);
                Board[fromRow][iFromCol]= null;
                Board[toRow][iToCol]=temp;
                turn=false;
                return true;
            }
        }
        else
        {
            if(turn==false && Board[fromRow][iFromCol].isBlack()==false)
            {
                if(KnightValidMove(fromRow, iFromCol, toRow, iToCol, Board, turn)==true)
                {
                    Knight temp = new Knight(toRow, iToCol, false);
                    Board[fromRow][iFromCol]= null;
                    Board[toRow][iToCol]=temp;
                    turn=true;
                    return true;
                }
            }
        }
        return false;
    }
}







