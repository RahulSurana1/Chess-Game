
import java.util.Scanner;

public class chessDriver
{

    public static void main(String[] args)
    {
        ChessBoard board = new ChessBoard(8);

        for(int c=0; c<board.length();c++)
        {
            Pawn temp = new Pawn(1, c, true);
            board.addPiece(1, c, temp);
            Pawn temp2 = new Pawn(6,c,false);
            board.addPiece(6, c, temp2);
        }
        for(int c=0; c<board.length();c++)
        {
            if(c==0)
            {
                Rook temp = new Rook(0,c,true);
                board.addPiece(0, c, temp);
                Rook temp2 = new Rook(7,c,false);
                board.addPiece(7, c, temp2);
            }
            if(c==1)
            {
                Knight temp= new Knight(0,c,true);
                board.addPiece(0, c, temp);
                Knight temp2= new Knight(7,c,false);
                board.addPiece(7, c, temp2);
            }
            if(c==2)
            {
                Bishop temp = new Bishop(0,c,true);
                board.addPiece(0, c, temp);
                Bishop temp2 = new Bishop(7,c,false);
                board.addPiece(7, c, temp2);
            }
            if(c==3)
            {
                Queen temp = new Queen(0,c,true);
                board.addPiece(0, c, temp);
                Queen temp2 = new Queen(7,c,false);
                board.addPiece(7, c, temp2);
            }
            if(c==4)
            {
                King temp = new King(0,c,true);
                board.addPiece(0, c, temp);
                King temp2 = new King(7,c,false);
                board.addPiece(7, c, temp2);
            }
            if(c==5)
            {
                Bishop temp = new Bishop(0,c,true);
                board.addPiece(0, c, temp);
                Bishop temp2 = new Bishop(7,c,false);
                board.addPiece(7, c, temp2);
            }
            if(c==6)
            {
                Knight temp= new Knight(0,c,true);
                board.addPiece(0, c, temp);
                Knight temp2= new Knight(7,c,false);
                board.addPiece(7, c, temp2);
            }
            if(c==7)
            {
                Rook temp = new Rook(0,c,true);
                board.addPiece(0, c, temp);
                Rook temp2 = new Rook(7,c,false);
                board.addPiece(7, c, temp2);
            }
        }

        Scanner scan= new Scanner(System.in);

        while(board.isWin()==false)
        {
            int fromRow=100;
            char fromCol='z';
            int toRow=100;
            char toCol='z';
            String location;

            board.printBoard();

            if (board.blackTurn()==false)
            {
                System.out.println("White, it is your turn.");
            }
            else
            {
                System.out.println("Black, it is your turn.");
            }

            System.out.println("Capitals for White. Lowercase for Black.");
            System.out.println("Pawn: P/p Rook: R/r Knight: K/k Bishop: B/b Queen: Q/q King: X/x");
            System.out.println("Enter where the piece is: ex: a7");
            location=scan.next();
            fromCol=location.charAt(0);
            fromRow=location.charAt(1);

            System.out.println("Enter where you want the piece to go: ex: a5");
            location=scan.next();
            toCol=location.charAt(0);
            toRow=location.charAt(1);

            if(board.move(fromRow,fromCol,toRow,toCol)==false)
            {
                System.out.println("Invalid Move. Please try again.");
            }
            else
            {
                if(ChessBoard.checkCheckmate()==true)
                    break;
            }

        }
    }

}










